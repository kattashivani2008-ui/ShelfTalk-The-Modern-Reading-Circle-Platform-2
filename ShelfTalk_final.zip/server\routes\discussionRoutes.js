import { Router } from 'express';
import { DiscussionsDao } from '../db/database.js';
import { validateDiscussionInput } from '../middleware/validation.js';
import { authenticateToken } from '../middleware/auth.js';
import { registerSseClient, unregisterSseClient, broadcastPost } from '../sse.js';

const router = Router();

// Legacy export kept for any direct callers
export const broadcastDiscussionPost = broadcastPost;

// GET /api/discussions - Fetch chapter posts (public)
router.get('/', (req, res, next) => {
  try {
    const { circleId, chapterId } = req.query;
    if (!circleId) {
      return res.status(400).json({ success: false, error: 'circleId query parameter is required.' });
    }

    const posts = DiscussionsDao.getByCircle(circleId, chapterId);
    res.json({ success: true, count: posts.length, data: posts });
  } catch (err) {
    next(err);
  }
});

// POST /api/discussions - Post thought (requires authentication)
router.post('/', authenticateToken, validateDiscussionInput, (req, res, next) => {
  try {
    const { circleId, chapterId, chapterTitle, authorName, content, containsSpoilers } = req.body;

    const post = DiscussionsDao.create({
      circleId,
      chapterId: chapterId || 'general',
      chapterTitle: chapterTitle || 'Chapter Discussion',
      authorName,
      content,
      containsSpoilers
    });

    broadcastPost(post);

    res.status(201).json({
      success: true,
      message: 'Chapter post submitted.',
      data: post
    });
  } catch (err) {
    next(err);
  }
});

// GET /api/discussions/stream - Real-time Server-Sent Events stream
router.get('/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  registerSseClient(res);

  req.on('close', () => {
    unregisterSseClient(res);
  });
});

export default router;
