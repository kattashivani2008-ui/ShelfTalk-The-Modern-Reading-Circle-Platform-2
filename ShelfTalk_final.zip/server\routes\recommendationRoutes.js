import { Router } from 'express';
import { BooksDao } from '../db/database.js';
import { cache } from '../cache.js';

const router = Router();

// ---------------------------------------------------------------------------
// Cosine Vector Affinity Engine  v3
// ---------------------------------------------------------------------------
// Books and user queries are encoded as 5-dimension feature vectors.
// Cosine similarity gives a magnitude-independent score in [0, 1].
//
// Dimensions:
//  [0] genreMatch       — 1.0 if book carries the requested genre, else 0
//  [1] pacingMatch      — 1.0 if page-count tier fits requested pacing
//                         brisk ≤ 350 pp  |  epic ≥ 500 pp
//                         reflective = Fiction  |  actionable = Non-Fiction
//  [2] qualityScore     — normalised average rating  (averageRating / 5)
//  [3] popularityScore  — normalised review count capped at 50
//  [4] themeScore       — TF-IDF-lite: Jaccard overlap between query theme
//                         keywords and synopsis unigrams
//
// Cache: results are memoised with a 60-second TTL keyed on the query triple
// (genre, pacing, theme). Invalidated on database reset.
// ---------------------------------------------------------------------------

const GENRE_ALIASES = {
  fiction:    ['Fiction'],
  scifi:      ['Sci-Fi', 'Science Fiction'],
  nonfiction: ['Non-Fiction'],
  biography:  ['Biography'],
};

/** Resolve user-supplied genre string to canonical genre labels */
function resolveGenres(genre) {
  if (!genre) return [];
  const key = genre.toLowerCase().replace(/[^a-z]/g, '');
  return GENRE_ALIASES[key] || [genre];
}

/**
 * Tokenise a string into a Set of lowercase word stems (stop-words removed).
 * This gives a cheap vocabulary for Jaccard overlap without an NLP library.
 */
const STOP_WORDS = new Set([
  'a','an','the','and','or','but','in','on','at','to','for','of','with',
  'is','was','are','were','be','been','has','have','had','it','its','this',
  'that','from','by','as','into','about','after','between','through','their',
  'they','which','who','what','when','how','not','no','so','if','then','than',
  'up','out','more','most','also','some','any','all','each','both','there'
]);

function tokenise(text) {
  if (!text) return new Set();
  return new Set(
    text.toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 2 && !STOP_WORDS.has(w))
  );
}

/** Jaccard similarity: |A ∩ B| / |A ∪ B| */
function jaccard(setA, setB) {
  if (setA.size === 0 && setB.size === 0) return 0;
  let intersection = 0;
  for (const t of setA) { if (setB.has(t)) intersection++; }
  const union = setA.size + setB.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

/** Encode a book into a 5-dimension feature vector */
function encodeBook(book, queryGenres, pacing, queryTokens) {
  const genreMatch = queryGenres.length > 0 && queryGenres.some(g => book.genres.includes(g)) ? 1 : 0;

  let pacingMatch = 0;
  if (pacing === 'brisk'      && book.pageCount <= 350)               pacingMatch = 1;
  if (pacing === 'epic'       && book.pageCount >= 500)               pacingMatch = 1;
  if (pacing === 'reflective' && book.genres.includes('Fiction'))     pacingMatch = 1;
  if (pacing === 'actionable' && book.genres.includes('Non-Fiction')) pacingMatch = 1;

  const qualityScore    = (book.averageRating || 0) / 5;
  const popularityScore = Math.min(book.totalReviews || 0, 50) / 50;
  const themeScore      = queryTokens.size > 0
    ? jaccard(queryTokens, tokenise(book.synopsis))
    : 0;

  return [genreMatch, pacingMatch, qualityScore, popularityScore, themeScore];
}

/** Encode the user query as the ideal 5-dimension target vector */
function encodeQuery(queryGenres, pacing, queryTokens) {
  return [
    queryGenres.length > 0 ? 1 : 0,
    pacing ? 1 : 0,
    1,                             // prefer highest quality
    1,                             // prefer most popular
    queryTokens.size > 0 ? 1 : 0  // prefer theme match when theme provided
  ];
}

/** Cosine similarity of two equal-length numeric vectors */
function cosineSimilarity(a, b) {
  const dot  = a.reduce((s, v, i) => s + v * b[i], 0);
  const magA = Math.sqrt(a.reduce((s, v) => s + v * v, 0));
  const magB = Math.sqrt(b.reduce((s, v) => s + v * v, 0));
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

/** Human-readable explanation of why a book matched */
function buildMatchReason(book, queryGenres, pacing, similarity, themeScore) {
  const parts = [];
  if (queryGenres.length > 0 && queryGenres.some(g => book.genres.includes(g))) {
    parts.push(`matches your ${queryGenres[0]} preference`);
  }
  if (pacing) parts.push(`suits ${pacing} pacing`);
  if (book.averageRating >= 4.5) parts.push(`community favourite at ${book.averageRating}★`);
  if (themeScore > 0.05) parts.push(`thematic synopsis overlap`);
  const pct = Math.round(similarity * 100);
  return parts.length > 0
    ? `${pct}% affinity — ${parts.join(', ')}.`
    : `${pct}% affinity based on quality and popularity signals.`;
}

// ---------------------------------------------------------------------------

/**
 * @openapi
 * /api/recommendations/match:
 *   post:
 *     summary: Recommend books using cosine vector affinity (5-dimension, TTL-cached)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               genre:  { type: string, example: Fiction }
 *               pacing: { type: string, enum: [brisk, epic, reflective, actionable] }
 *               theme:  { type: string, description: Free-text thematic keywords used for synopsis overlap scoring }
 *     responses:
 *       200:
 *         description: Top match and three alternates with affinityPercentage, matchReason, and cache metadata
 */
router.post('/match', (req, res, next) => {
  try {
    const { genre, pacing, theme } = req.body;

    // Normalise theme: accept both string and legacy { targetBookId } object shapes
    const themeText = typeof theme === 'string' ? theme : '';
    const queryTokens = tokenise(themeText);

    // Cache key encodes the full query triple
    const cacheKey = `rec:${(genre || '').toLowerCase()}:${pacing || ''}:${themeText.slice(0, 60)}`;
    const cached = cache.get(cacheKey);
    if (cached) {
      return res.json({ ...cached, cached: true, cacheStats: cache.stats() });
    }

    const queryGenres = resolveGenres(genre);
    const queryVec    = encodeQuery(queryGenres, pacing, queryTokens);

    const { data: allBooks } = BooksDao.getAll(undefined, undefined, 1, 100);

    const scored = allBooks.map((book) => {
      const bookVec      = encodeBook(book, queryGenres, pacing, queryTokens);
      const similarity   = cosineSimilarity(queryVec, bookVec);
      const themeScore   = bookVec[4];

      // Map [0,1] cosine score to a [60,99] display percentage for readability
      const affinityPercentage = Math.round(60 + similarity * 39);

      return {
        book,
        affinityPercentage,
        matchReason: buildMatchReason(book, queryGenres, pacing, similarity, themeScore),
        _score: similarity
      };
    });

    scored.sort((a, b) => b._score - a._score);
    const clean = scored.map(({ _score, ...rest }) => rest);

    const result = {
      success: true,
      algorithm: 'cosine-vector-affinity-v3',
      dimensions: ['genreMatch', 'pacingMatch', 'qualityScore', 'popularityScore', 'themeScore'],
      topMatch:   clean[0],
      alternates: clean.slice(1, 4),
      cached: false,
      cacheStats: cache.stats()
    };

    // Memoize for 60 seconds
    cache.set(cacheKey, result, 60);

    res.json(result);
  } catch (err) {
    next(err);
  }
});

export default router;
