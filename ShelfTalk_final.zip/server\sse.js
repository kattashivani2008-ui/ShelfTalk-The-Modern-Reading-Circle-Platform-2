/**
 * SSE (Server-Sent Events) broadcast layer
 *
 * Current implementation: in-process Set of response objects.
 * This works correctly for a single-process deployment (Node.js cluster
 * primary, or a single Docker container).
 *
 * Horizontal scaling path (multiple containers / processes):
 *   Replace the in-process Set with a Redis Pub/Sub channel.
 *   Each process subscribes to the same channel; a post on any process
 *   publishes to Redis and every subscriber fans it out to its own
 *   connected clients. The interface below is intentionally compatible
 *   with that swap — only this file needs to change.
 *
 *   // Redis adapter (drop-in replacement):
 *   import { createClient } from 'redis';
 *   const pub = createClient(); const sub = pub.duplicate();
 *   await pub.connect(); await sub.connect();
 *   sub.subscribe('shelftalk:posts', (msg) => fanOut(JSON.parse(msg)));
 *   export const broadcastPost = (post) => pub.publish('shelftalk:posts', JSON.stringify(post));
 *
 * Usage:
 *   import { registerSseClient, unregisterSseClient, broadcastPost } from '../sse.js';
 */

/** @type {Set<import('express').Response>} */
const clients = new Set();

/** Register an SSE response object as a connected client. */
export function registerSseClient(res) {
  clients.add(res);
}

/** Remove a client when their connection closes. */
export function unregisterSseClient(res) {
  clients.delete(res);
}

/** Fan a new post out to every connected client. */
export function broadcastPost(post) {
  const payload = `data: ${JSON.stringify({ type: 'NEW_CHAPTER_POST', post })}\n\n`;
  for (const client of clients) {
    try {
      client.write(payload);
    } catch {
      clients.delete(client); // remove stale connections silently
    }
  }
}

/** Active connection count — useful for health/metrics endpoints. */
export function sseClientCount() {
  return clients.size;
}
