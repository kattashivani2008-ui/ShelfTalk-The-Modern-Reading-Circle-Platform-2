/**
 * Authentication routes
 *
 * POST /api/auth/register  — create a new user account (reader role by default)
 * POST /api/auth/login     — exchange credentials for a signed JWT
 * POST /api/auth/refresh   — issue a fresh token from a still-valid one
 *
 * User accounts are stored in the SQLite `users` table (see schema.sql).
 * Passwords are hashed with PBKDF2-SHA256 (100 000 iterations) using
 * node:crypto — no bcrypt dependency required.
 *
 * Token lifetime: 24 hours (configurable via JWT_TTL_HOURS env var).
 * Brute-force protection: auth endpoints are behind a tight rate limiter
 * (10 req / 15 min per IP), separate from the global API limiter.
 */

import { Router } from 'express';
import { pbkdf2Sync, randomBytes } from 'node:crypto';
import rateLimit from 'express-rate-limit';
import { db } from '../db/database.js';
import { sign, verify, authenticateToken } from '../middleware/auth.js';
import { logger } from '../logger.js';

const router = Router();

const TTL_HOURS  = parseInt(process.env.JWT_TTL_HOURS || '24', 10);
const ITERATIONS = 100_000;
const KEY_LEN    = 64;
const DIGEST     = 'sha256';

// Tight brute-force limiter for auth endpoints: 10 attempts per 15 min per IP
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many auth attempts. Please wait 15 minutes.' }
});

/** Hash a password with a random salt using PBKDF2 */
function hashPassword(password, salt = randomBytes(16).toString('hex')) {
  const hash = pbkdf2Sync(password, salt, ITERATIONS, KEY_LEN, DIGEST).toString('hex');
  return { hash, salt };
}

/** Verify a plain-text password against a stored hash+salt */
function verifyPassword(password, storedHash, salt) {
  const { hash } = hashPassword(password, salt);
  // Timing-safe comparison
  const a = Buffer.from(hash,       'hex');
  const b = Buffer.from(storedHash, 'hex');
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

// ---------------------------------------------------------------------------

/**
 * @openapi
 * /api/auth/register:
 *   post:
 *     summary: Register a new user account
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [username, password]
 *             properties:
 *               username: { type: string, minLength: 3, maxLength: 40 }
 *               password: { type: string, minLength: 8 }
 *               role:     { type: string, enum: [reader, organizer], default: reader }
 *     responses:
 *       201: { description: Account created; JWT returned }
 *       400: { description: Validation error or username taken }
 */
router.post('/register', authLimiter, (req, res, next) => {
  try {
    const { username, password, role = 'reader' } = req.body;

    if (!username || typeof username !== 'string' || username.trim().length < 3) {
      return res.status(400).json({ success: false, error: 'username must be at least 3 characters.' });
    }
    if (!password || typeof password !== 'string' || password.length < 8) {
      return res.status(400).json({ success: false, error: 'password must be at least 8 characters.' });
    }
    if (!['reader', 'organizer'].includes(role)) {
      return res.status(400).json({ success: false, error: "role must be 'reader' or 'organizer'." });
    }

    const clean = username.trim().slice(0, 40).toLowerCase();

    // Check uniqueness
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(clean);
    if (existing) {
      return res.status(400).json({ success: false, error: 'Username already taken.' });
    }

    const { hash, salt } = hashPassword(password);
    const id = `user-${Date.now()}`;
    db.prepare('INSERT INTO users (id, username, password_hash, salt, role) VALUES (?, ?, ?, ?, ?)')
      .run(id, clean, hash, salt, role);

    const secret = process.env.JWT_SECRET;
    if (!secret) {
      return res.status(201).json({ success: true, message: 'Account created. Set JWT_SECRET to enable token issuance.' });
    }

    const exp   = Math.floor(Date.now() / 1000) + TTL_HOURS * 3600;
    const token = sign({ sub: id, username: clean, role, exp }, secret);

    logger.info({ username: clean, role }, 'User registered');
    res.status(201).json({ success: true, token, expiresIn: `${TTL_HOURS}h`, role });
  } catch (err) {
    next(err);
  }
});

/**
 * @openapi
 * /api/auth/login:
 *   post:
 *     summary: Authenticate and receive a JWT
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [username, password]
 *             properties:
 *               username: { type: string }
 *               password: { type: string }
 *     responses:
 *       200: { description: JWT token returned }
 *       401: { description: Invalid credentials }
 */
router.post('/login', authLimiter, (req, res, next) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ success: false, error: 'username and password are required.' });
    }

    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username.trim().toLowerCase());
    if (!user || !verifyPassword(password, user.password_hash, user.salt)) {
      // Identical message for both "not found" and "wrong password" to prevent enumeration
      return res.status(401).json({ success: false, error: 'Invalid credentials.' });
    }

    const secret = process.env.JWT_SECRET;
    if (!secret) {
      return res.status(503).json({ success: false, error: 'Authentication service not configured.' });
    }

    const exp   = Math.floor(Date.now() / 1000) + TTL_HOURS * 3600;
    const token = sign({ sub: user.id, username: user.username, role: user.role, exp }, secret);

    logger.info({ username: user.username, role: user.role }, 'User logged in');
    res.json({ success: true, token, expiresIn: `${TTL_HOURS}h`, role: user.role });
  } catch (err) {
    next(err);
  }
});

/**
 * @openapi
 * /api/auth/refresh:
 *   post:
 *     summary: Refresh a JWT without re-entering credentials
 *     description: Accepts a still-valid Bearer token and returns a new one with a fresh expiry.
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200: { description: New JWT returned }
 *       401: { description: No token provided }
 *       403: { description: Token invalid or expired }
 */
router.post('/refresh', authenticateToken, (req, res, next) => {
  try {
    const secret = process.env.JWT_SECRET;
    if (!secret) {
      return res.status(503).json({ success: false, error: 'Authentication service not configured.' });
    }

    const { sub, username, role } = req.user;
    const exp   = Math.floor(Date.now() / 1000) + TTL_HOURS * 3600;
    const token = sign({ sub, username, role, exp }, secret);

    logger.info({ username, role }, 'Token refreshed');
    res.json({ success: true, token, expiresIn: `${TTL_HOURS}h`, role });
  } catch (err) {
    next(err);
  }
});

export default router;
