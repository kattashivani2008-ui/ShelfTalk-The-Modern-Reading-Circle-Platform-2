# ShelfTalk — Architecture Decision Record

## System Overview

ShelfTalk is a 3-tier web application:

```
Browser (React 18)
      │  HTTP/REST + SSE
      ▼
Express API  (Node.js 20, ES Modules)
      │  Prepared statements
      ▼
SQLite 3  (WAL mode, node:sqlite)
```

---

## Key Design Decisions

### 1. Authentication — Stateless JWT (HS256)

**Decision:** Implement JWT-based auth using `node:crypto` (no external library).  
**Why:** Stateless tokens scale horizontally without a session store. PBKDF2-SHA256 with 100 000 iterations meets NIST SP 800-132 guidance. Timing-safe comparison prevents timing-attack credential enumeration.

**Token lifecycle:**
```
POST /api/auth/register  →  { token, role, expiresIn }
POST /api/auth/login     →  { token, role, expiresIn }
POST /api/auth/refresh   →  { token }   (extends expiry without re-login)
```

**RBAC:** Two roles — `reader` (can post reviews, discussions, quotes) and `organizer` (can manage circles). The `requireRole()` middleware enforces this per-route.

**Demo mode:** When `JWT_SECRET` is unset, `authenticateToken` passes all requests through with a demo identity so the app runs without configuration.

---

### 2. Recommendation Engine — Cosine Vector Affinity (5-dimension)

**Decision:** Encode books as 5-dimension feature vectors and rank by cosine similarity.  
**Why:** Cosine similarity is magnitude-independent — a niche book with one perfect feature is not buried under a popular book with weak matches across many features.

```
Vector dimensions:
  [0] genreMatch      — binary (1 if book genre matches query)
  [1] pacingMatch     — binary (page-count tier vs requested pacing)
  [2] qualityScore    — averageRating / 5
  [3] popularityScore — min(totalReviews, 50) / 50
  [4] themeScore      — Jaccard overlap: query keywords ∩ synopsis unigrams
```

**Caching:** Results are memoised in a TTL-LRU in-process cache (`server/cache.js`) with a Redis-compatible interface (`get / set / del / delByPrefix`). Migration to Redis requires changing only that file.

---

### 3. Real-Time Discussions — Server-Sent Events (SSE)

**Decision:** Use SSE over WebSockets for the live discussion stream.  
**Why:** SSE is unidirectional (server → client), HTTP/1.1 compatible, and requires no upgrade handshake. Discussions are read-heavy; full-duplex is not needed.

**Scaling path:** The SSE broadcast layer (`server/sse.js`) is extracted from route code. The current implementation uses an in-process `Set`. Horizontal scaling (multiple containers) requires replacing it with a Redis Pub/Sub adapter — the interface is designed for that swap:

```
Single process:   POST /api/discussions  →  broadcastPost()  →  in-process Set
Multi-process:    POST /api/discussions  →  broadcastPost()  →  Redis PUBLISH
                                                   ↓
                                         Redis SUBSCRIBE (all processes)
                                                   ↓
                                          each process fans out to its clients
```

---

### 4. Data Access — DAO Pattern

**Decision:** All SQL is isolated in Data Access Objects inside `server/db/database.js`.  
**Why:** Routes never construct SQL strings. Prepared statements prevent SQL injection. DAOs are testable in isolation without an HTTP server.

```
Route handler  →  DAO method  →  db.prepare().run() / .get() / .all()
```

---

### 5. Containerization — Multi-Stage Docker Build

**Decision:** Two-stage `Dockerfile` (builder + runtime), `docker-compose.yml` with named volume.  
**Why:** Stage 1 compiles the React frontend. Stage 2 is a lean `node:20-alpine` image (~150 MB) with no devDependencies. The non-root `shelftalk` user limits container blast radius. The SQLite file lives in a named Docker volume so it survives `docker compose restart`.

```
builder  →  npm ci (dev) + npm run build  →  dist/
runtime  →  npm ci (prod only) + COPY dist/ + COPY server/
```

---

### 6. Security Layers (defence in depth)

| Layer | Implementation |
|:---|:---|
| Transport headers | Helmet (CSP, HSTS, X-Frame-Options, nosniff) |
| Cross-origin | CORS allowlist (localhost:3000 / 5000) |
| Rate limiting — global | 200 req / 15 min / IP |
| Rate limiting — auth | 10 req / 15 min / IP (brute-force protection) |
| Input validation | `server/middleware/validation.js` — type + bounds checks |
| Password storage | PBKDF2-SHA256, 100 000 iterations, random salt |
| Token signing | HS256, timing-safe signature verification |
| DB injection | Prepared statements only — no string interpolation |
| Secrets | Environment variables only — `.env.example` provided, `.env` gitignored |
