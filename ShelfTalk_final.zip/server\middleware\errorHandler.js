import { logger } from '../logger.js';

/**
 * Centralized Application Error Handling Middleware
 * Prevents stack trace leakage in production while logging diagnostics.
 * Includes specific recovery paths for SQLite lock contention (SQLITE_BUSY).
 */
export const errorHandler = (err, req, res, next) => {
  // --- SQLite lock contention: advise client to retry ---
  if (err.code === 'SQLITE_BUSY' || (err.message && err.message.includes('database is locked'))) {
    logger.warn({ method: req.method, url: req.url, code: err.code }, 'DB lock contention — advising retry');
    return res.status(503).json({
      success: false,
      error: 'The database is temporarily busy. Please retry in a moment.',
      retryAfterMs: 500,
      timestamp: new Date().toISOString()
    });
  }

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';

  if (statusCode >= 500) {
    logger.error({ method: req.method, url: req.url, statusCode, err }, 'Server error');
  } else {
    logger.warn({ method: req.method, url: req.url, statusCode, message }, 'Client error');
  }

  res.status(statusCode).json({
    success: false,
    error: message,
    timestamp: new Date().toISOString()
  });
};
