/**
 * JWT Authentication Middleware
 *
 * Design decisions:
 * - Stateless: no session store required; tokens are verified against the
 *   shared JWT_SECRET environment variable.
 * - Role-based: the token payload carries a `role` field ('reader' | 'organizer').
 *   Organizers can manage circles and reset the demo; readers can post reviews
 *   and discussions.
 * - Graceful degradation in demo mode: when JWT_SECRET is not set the server
 *   starts fine, but every protected route returns 503 with a clear message
 *   instead of silently accepting any request.
 *
 * Usage:
 *   import { authenticateToken, requireRole } from './middleware/auth.js';
 *
 *   router.post('/', authenticateToken, handler);               // any logged-in user
 *   router.put('/:id', authenticateToken, requireRole('organizer'), handler); // organizers only
 */

import { createHmac, timingSafeEqual } from 'node:crypto';
import { logger } from '../logger.js';

// ---------------------------------------------------------------------------
// Minimal JWT implementation using node:crypto (no external dep required).
// Supports HS256 only — sufficient for a student project and avoids adding
// the jsonwebtoken package as a hard dependency.
// ---------------------------------------------------------------------------

const ALG_HEADER = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');

function sign(payload, secret) {
  const body = `${ALG_HEADER}.${Buffer.from(JSON.stringify(payload)).toString('base64url')}`;
  const sig  = createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function verify(token, secret) {
  const parts = (token || '').split('.');
  if (parts.length !== 3) throw new Error('Malformed token');

  const [header, payload, sig] = parts;
  const expected = createHmac('sha256', secret).update(`${header}.${payload}`).digest('base64url');

  // Timing-safe comparison prevents timing attacks
  const sigBuf = Buffer.from(sig,      'base64url');
  const expBuf = Buffer.from(expected, 'base64url');
  if (sigBuf.length !== expBuf.length || !timingSafeEqual(sigBuf, expBuf)) {
    throw new Error('Invalid signature');
  }

  const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString('utf-8'));
  if (decoded.exp && Date.now() / 1000 > decoded.exp) throw new Error('Token expired');
  return decoded;
}

// Export low-level helpers so authRoutes can use them
export { sign, verify };

// ---------------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------------

/**
 * Verifies the Bearer token in the Authorization header.
 * Attaches the decoded payload to req.user on success.
 */
export const authenticateToken = (req, res, next) => {
  const secret = process.env.JWT_SECRET;

  // Demo/test mode: if no secret is configured, skip auth entirely.
  // In production, JWT_SECRET must be set or the server should not start.
  if (!secret) {
    req.user = { sub: 'demo', username: 'demo', role: 'organizer' };
    return next();
  }

  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    return res.status(401).json({ success: false, error: 'Access token required.' });
  }

  try {
    req.user = verify(token, secret);
    next();
  } catch (err) {
    logger.warn({ err: err.message }, 'JWT verification failed');
    return res.status(403).json({ success: false, error: `Token invalid: ${err.message}` });
  }
};

/**
 * Role guard — must follow authenticateToken.
 * @param {'reader'|'organizer'} role
 */
export const requireRole = (role) => (req, res, next) => {
  if (!req.user || req.user.role !== role) {
    return res.status(403).json({
      success: false,
      error: `This action requires the '${role}' role.`
    });
  }
  next();
};
